Bu proje, Kaggle'dan indirilen SpotifyFeatures veri setinin analizinin yapılıp,
bu analiz doğrultusunda verilerin görselleştirilmesi ve gerekli ML modellemesinin
yapılışını barındırmaktadır.

Projeyi anlatan video linki:https://youtu.be/0_qSNBotK4M